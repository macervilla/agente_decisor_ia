import os
import unicodedata
from datetime import datetime, timezone
from uuid import uuid4

from dotenv import load_dotenv

from app.database import base_datos
from app.services.api_externa_service import (
    ErrorAPIExterna,
    consultar_pais,
    formatear_respuesta_pais,
)
from app.services.decisor_service import decidir_herramientas
from app.services.ia_service import ErrorIA, generar_respuesta
from app.services.rag_service import ErrorRAG, preguntar_documentos

load_dotenv()

OLLAMA_MODELO = os.getenv("OLLAMA_MODELO", "llama3.2:3b")

coleccion_conversaciones = base_datos["conversaciones"]


class ErrorAgente(Exception):
    pass


def _normalizar_texto(texto: str) -> str:
    texto = unicodedata.normalize("NFD", texto.lower())
    return "".join(
        caracter
        for caracter in texto
        if unicodedata.category(caracter) != "Mn"
    )


def _pregunta_sobre_memoria(pregunta: str) -> bool:
    pregunta_normalizada = _normalizar_texto(pregunta)
    expresiones_memoria = (
        "pregunta anterior",
        "pregunte antes",
        "te pregunte",
        "que hablamos",
        "de que hablamos",
        "que conversamos",
        "conversacion anterior",
        "historial",
        "que te dije",
        "te habia dicho",
        "recordas",
        "recuerdas",
        "que recuerdas",
        "que sabes de mi",
    )
    return any(
        expresion in pregunta_normalizada
        for expresion in expresiones_memoria
    )


def _obtener_historial(
    usuario: str,
    conversacion_id: str | None,
) -> list[dict]:
    if not conversacion_id:
        return []
    registros = list(
        coleccion_conversaciones.find(
            {
                "usuario": usuario,
                "conversacion_id": conversacion_id,
            },
            {"_id": 0, "pregunta": 1, "respuesta": 1},
        ).sort("fecha", -1).limit(10)
    )
    registros.reverse()
    return registros


def _es_pregunta_anterior(pregunta: str) -> bool:
    pregunta_normalizada = _normalizar_texto(pregunta)
    expresiones = (
        "pregunta anterior",
        "pregunte antes",
        "te pregunte",
        "ultima pregunta",
    )
    return any(
        expresion in pregunta_normalizada
        for expresion in expresiones
    )


def _obtener_pregunta_anterior(historial: list[dict]) -> str | None:
    for intercambio in reversed(historial):
        pregunta = intercambio.get("pregunta", "").strip()
        if pregunta and not _pregunta_sobre_memoria(pregunta):
            return pregunta
    return None


def _guardar_intercambio(
    usuario: str,
    conversacion_id: str,
    pregunta: str,
    respuesta: str,
    herramienta: str,
) -> None:
    coleccion_conversaciones.insert_one(
        {
            "usuario": usuario,
            "conversacion_id": conversacion_id,
            "tipo": "agente",
            "herramienta": herramienta,
            "pregunta": pregunta,
            "respuesta": respuesta,
            "modelo": OLLAMA_MODELO,
            "fecha": datetime.now(timezone.utc),
        }
    )


def consultar_agente(
    usuario: str,
    pregunta: str,
    documento_id: str | None = None,
    conversacion_id: str | None = None,
) -> dict:
    usuario = usuario.strip()
    pregunta = pregunta.strip()
    if not usuario:
        raise ErrorAgente("El usuario no puede estar vacío")
    if not pregunta:
        raise ErrorAgente("La pregunta no puede estar vacía")

    conversacion_id = conversacion_id or str(uuid4())
    decision = decidir_herramientas(pregunta, documento_id)
    herramientas = decision["herramientas"]

    # Hasta incorporar ejecutor_service, conservamos la ejecución actual
    # de una herramienta. El decisor ya informa todas las seleccionadas.
    herramienta = herramientas[0] if herramientas else "directa"
    fuente = None

    try:
        if herramienta == "documentos":
            resultado = preguntar_documentos(
                usuario=usuario,
                pregunta=pregunta,
                documento_id=documento_id,
                conversacion_id=conversacion_id,
            )
            respuesta = resultado["respuesta"]
            fragmentos = resultado["fragmentos_utilizados"]
        elif herramienta == "api_externa":
            datos_pais = consultar_pais(pregunta)
            respuesta = formatear_respuesta_pais(datos_pais)
            fuente = datos_pais["fuente"]
            fragmentos = 0
            _guardar_intercambio(
                usuario,
                conversacion_id,
                pregunta,
                respuesta,
                herramienta,
            )
        else:
            historial = (
                _obtener_historial(usuario, conversacion_id)
                if herramienta == "mongodb"
                else []
            )
            if herramienta == "mongodb" and _es_pregunta_anterior(pregunta):
                pregunta_anterior = _obtener_pregunta_anterior(historial)
                respuesta = (
                    f'Tu pregunta anterior fue: "{pregunta_anterior}".'
                    if pregunta_anterior
                    else "No encontré una pregunta anterior "
                    "en esta conversación."
                )
            else:
                respuesta = generar_respuesta(
                    pregunta,
                    historial,
                )["texto"].strip()
            fragmentos = 0
            _guardar_intercambio(
                usuario,
                conversacion_id,
                pregunta,
                respuesta,
                herramienta,
            )
    except (ErrorIA, ErrorRAG, ErrorAPIExterna) as error:
        raise ErrorAgente(str(error)) from error

    return {
        "usuario": usuario,
        "pregunta": pregunta,
        "respuesta": respuesta,
        "herramienta_utilizada": herramienta,
        "herramientas_seleccionadas": herramientas,
        "motivo_decision": decision["motivo"],
        "conversacion_id": conversacion_id,
        "documento_id": documento_id,
        "fragmentos_utilizados": fragmentos,
        "modelo": OLLAMA_MODELO,
        "fuente": fuente,
    }
